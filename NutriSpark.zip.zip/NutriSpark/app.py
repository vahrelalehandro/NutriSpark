from system import KnowledgeBase, ExpertSystem
import time
import sys 

kb = KnowledgeBase(["food data 1.csv","food data 2.csv","food data 3.csv"])
engine = ExpertSystem(kb) 

nutrient = [
    "Caloric Value",
    "Protein",
    "Fat",
    "Carbohydrates",
    "Dietary Fiber",
    "Sugars",
    "Vitamin C",
    "Vitamin E"
]

def health_tips():
    print("Healthy Lifestyle Tips :")
    print("💠 Consume a balanced and nutritious diet")
    print("💠 Workout")
    print("💠 Stress management")
    print("💠 Have health check-ups")
    print("💠 Get enough rest")
    print("💠 Stop smoking")
    print("💠 Drinking water")
    
def load():
    print("Find data", end="")
    for _ in range(2):
        print(".", end="", flush=True)
        time.sleep(0.5)
    print("\n")

def analyze_food(user_input):
    result = engine.analyze(user_input) 
    load()

    if "error" in result:
        print("Not found!")
    else:
        print("Analyze Nutrition: ") 
        for n in nutrient:
            if n in result["nutrition"]:
                print(f". {n}: {result['nutrition'][n]}")
        
        if result["recommendations"]:
            print("Result:")
            for r in result['recommendations']:
                print(f"🎯 {r}") 
        print("\n")

def main():
    print("+-------------------------------------------+")
    print("|                 NutriSpark 🍀             |")
    print("|    Make your healthy journey with Us      |")
    print("+-------------------------------------------+")
        
    while True:
        user_input = input("Type food or tips: ").strip()

        if user_input.lower() in ["exit", "quit"]:
            print("Thank you for using NutriSpark 🍀") 
            break 
        elif user_input.lower() in ["tips", "healthy", "lifestyle"]:
            health_tips() 
        elif user_input == "":
            continue
        else:
            analyze_food(user_input)

if __name__ == "__main__":
    main()