import pandas as pd

class KnowledgeBase:
    def __init__(self, files):
        self.data = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)

    def get_food(self, name):
        result = self.data[self.data["food"] == name]
        return None if result.empty else result.iloc[0].to_dict()


class ExpertSystem:
    def __init__(self, kb):
        self.kb = kb

    def analyze(self, user_input):
        food =  user_input.strip()
       
        data = self.kb.get_food(food)
        if not data:
            return {"error": True}

        rules = []

        if data["Protein"] > 20 and data["Fat"] < 5 and data["Caloric Value"] < 200:
            rules.append("High protein food suitable for muscle building")

        if data["Dietary Fiber"] > 3 and data["Caloric Value"] < 50 and data["Water"] > 80:
            rules.append("Good for weight loss and digestion")

        if data["Carbohydrates"] > 25 and data["Protein"] < 6 and data["Caloric Value"] > 100:
            rules.append("Good source of daily energy")

        if data["Vitamin C"] > 40 and data["Caloric Value"] < 100 and data["Sugars"] < 15:
            rules.append("Boosts immune system")

        if data["Vitamin E"] > 50 and data["Fat"] < 5 and data["Caloric Value"] < 100:
            rules.append("Supports eye health")

        if data["Iron"] > 2 and data["Caloric Value"] < 150 and data["Fat"] < 5:
            rules.append("Helps prevent anemia")

        if data["Sugars"] < 5 and data["Dietary Fiber"] > 2 and data["Caloric Value"] < 100:
            rules.append("Good for blood sugar control")

        if data["Fat"] > 10 and data["Protein"] > 10 and data["Carbohydrates"] < 5:
            rules.append("Suitable for low-carb diet")

        if data["Caloric Value"] > 180 and data["Protein"] > 15 and data["Fat"] > 8:
            rules.append("Recommended for bulking diet")

        if 50 <= data["Caloric Value"] <= 120 and data["Protein"] >= 2 and data["Carbohydrates"] <= 20:
            rules.append("Balanced daily food")

        return {
            "food": food,
            "nutrition": data,
            "recommendations": rules
        }

    def tips(self):
        return [
            "Eat balanced meals with vegetables and fruits",
            "Drink enough water daily",
            "Limit sugar and processed food",
            "Exercise regularly",
            "Get enough sleep"
        ]
